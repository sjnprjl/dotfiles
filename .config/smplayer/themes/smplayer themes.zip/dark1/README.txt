------------------------ SMPLAYER THEME PAPIRUS ------------------------
AUTHOR:
varlesh 
https://github.com/varlesh/papirus-pack-kde

LICENSE: GPL v3
